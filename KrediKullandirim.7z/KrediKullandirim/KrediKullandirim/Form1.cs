﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KrediKullandirim
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("ZİRAAT");
            comboBox1.Items.Add("GARANTİ");
            comboBox1.Items.Add("İŞBANKASI");

            comboBox2.Items.Add("3 AY");
            comboBox2.Items.Add("6 AY");
            comboBox2.Items.Add("12 AY");


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                KrediHesapla K = new KrediHesapla();

                K.KrediTutari = decimal.Parse(textBox1.Text);
                K.Bankaİsim = comboBox1.Text;
                K.Taksitsayisi = comboBox2.Text;

                MessageBox.Show("Geri Ödeme Tutarınız : " + K.KrediGeriOdeme());
            }
            catch (Exception)
            {

                MessageBox.Show("Gerekli Yerleri Doldurunuz");
            }
            
        }
    }
}
