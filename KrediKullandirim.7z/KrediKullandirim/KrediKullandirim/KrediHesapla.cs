﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KrediKullandirim
{
    public class KrediHesapla : HesapAbscrt
    {

        decimal sonuc;


        public override decimal KrediGeriOdeme()
        {
            if (Taksitsayisi == "3 AY") 
            
            {
                FaizOrani = 0.20M;
                sonuc = KrediTutari + (KrediTutari * FaizOrani);
            }
            if (Taksitsayisi == "6 AY")
            {

                if (Bankaİsim == "ZİRAAT")
                {
                    FaizOrani = 0.35M;
                    sonuc = KrediTutari + (KrediTutari * FaizOrani);

                }
                else 
                {

                    FaizOrani = 0.45M;
                    sonuc = KrediTutari + (KrediTutari * FaizOrani) +2000;
                }
            }
            if (Taksitsayisi == "12 AY")
            {

                if (Bankaİsim == "ZİRAAT")
                {
                    FaizOrani = 0.51M;
                    sonuc = KrediTutari + (KrediTutari * FaizOrani);

                }
                else if (Bankaİsim == "GARANTİ")
                {
                    FaizOrani = 0.53M;
                    sonuc = KrediTutari + (KrediTutari * FaizOrani);
                }
                else 
                
                {
                    FaizOrani = 0.52M;
                    sonuc = KrediTutari + (KrediTutari * FaizOrani) +2000 + 1200;
                }

            }



            return sonuc;



        }
    }
}
