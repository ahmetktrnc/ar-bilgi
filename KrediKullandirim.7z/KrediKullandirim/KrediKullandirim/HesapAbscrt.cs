﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KrediKullandirim
{
    public abstract class HesapAbscrt
    {
        public decimal KrediTutari { get; set; }
        public decimal FaizOrani { get; set; }
        public string Taksitsayisi { get; set; }
        public string Bankaİsim { get; set; }

        public abstract decimal KrediGeriOdeme();
    }
}
