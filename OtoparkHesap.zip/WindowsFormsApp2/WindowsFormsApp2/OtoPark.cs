﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    internal class OtoPark
    {
        double hesap;

        public double OtoparkHesap(bool indirim, double saat, double fiyat)

        {

            if (indirim == true)
            {
                hesap = (saat * fiyat) * 0.85;

            }
            else if (indirim == false)
            {
                hesap = saat * fiyat;
            }

            return hesap;
        }





      

    }
}






    

