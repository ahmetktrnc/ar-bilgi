﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace BayramOdev1
{
    internal class PizzaHesap
    {


public double SadePizzaHesap(string str1, string str2, bool ekstra1, bool ekstra2, bool ekstra3) 
        
        
        {

            double fiyat = 100;
            if (str1 == "İnce")

            {
                fiyat += 20;

            }
            if (str1 == "Normal")

            {
                fiyat += 30;

            }
            if (str1 == "Kalın")

            {
                fiyat += 30;

            }
            if (str2 == "Küçük")

            {
                fiyat += 5;

            }
            if (str2 == "Orta")

            {
                fiyat += 15;

            }
            if (str2 == "Büyük")

            {
                fiyat += 25;

            }
            if (ekstra1)
            {
                fiyat += 10;
            }
            if (ekstra2)
            {
                fiyat += 10;
            }
            if (ekstra3)
            {
                fiyat += 10;
            }
            return fiyat;
        }
        public double KarisikPizzaHesap(string str1, string str2, bool ekstra1, bool ekstra2, bool ekstra3)


        {

            double fiyat = 150;
            if (str1 == "İnce")

            {
                fiyat += 20;

            }
            if (str1 == "Normal")

            {
                fiyat += 30;

            }
            if (str1 == "Kalın")

            {
                fiyat += 30;

            }
            if (str2 == "Küçük")

            {
                fiyat += 5;

            }
            if (str2 == "Orta")

            {
                fiyat += 15;

            }
            if (str2 == "Büyük")

            {
                fiyat += 25;

            }
            if (ekstra1)
            {
                fiyat += 10;
            }
            if (ekstra2)
            {
                fiyat += 10;
            }
            if (ekstra3)
            {
                fiyat += 10;
            }


            return fiyat;
        }

        public double EtliPizzaHesap(string str1, string str2, bool ekstra1, bool ekstra2, bool ekstra3)


        {

            double fiyat = 200;
            if (str1 == "İnce")

            {
                fiyat += 20;

            }
            if (str1 == "Normal")

            {
                fiyat += 30;

            }
            if (str1 == "Kalın")

            {
                fiyat += 30;

            }
            if (str2 == "Küçük")

            {
                fiyat += 5;

            }
            if (str2 == "Orta")

            {
                fiyat += 15;

            }
            if (str2 == "Büyük")

            {
                fiyat += 25;

            }
            if (ekstra1)
            {
                fiyat += 10;
            }
            if (ekstra2)
            {
                fiyat += 10;
            }
            if (ekstra3)
            {
                fiyat += 10;
            }
            return fiyat;
        }



    }
}
