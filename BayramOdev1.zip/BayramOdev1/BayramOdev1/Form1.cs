﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BayramOdev1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CPizzaTuru.Items.Add("Sade");
            CPizzaTuru.Items.Add("Karışık");
            CPizzaTuru.Items.Add("Etli");
            CKenarTipi.Items.Add("İnce");
            CKenarTipi.Items.Add("Normal");
            CKenarTipi.Items.Add("Kalın");
            CBoyut.Items.Add("Küçük");
            CBoyut.Items.Add("Orta");
            CBoyut.Items.Add("Büyük");


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void HesaplaButon_Click(object sender, EventArgs e)
        {
            try
            {
                if (CPizzaTuru.Text == "")
                {

                    MessageBox.Show("Lütfen pizza türü seçiniz");

                }
                else if ( CBoyut.Text == "" )
                {
                    MessageBox.Show("Lütfen pizza boyutunu seçiniz");
                }
                else if (CKenarTipi.Text == "")
                {
                    MessageBox.Show("Lütfen pizza kenar tipi seçiniz");
                }

                else {

                    PizzaHesap H = new PizzaHesap();
                    if (CPizzaTuru.Text == "Sade")
                    {
                        MessageBox.Show("Toplam Tutar: " + " " + H.SadePizzaHesap(CKenarTipi.Text, CBoyut.Text, checkBox1.Checked, checkBox2.Checked, checkBox3.Checked));

                    }
                    if (CPizzaTuru.Text == "Karışık")
                    {
                        MessageBox.Show("Toplam Tutar: " + " " + H.KarisikPizzaHesap(CKenarTipi.Text, CBoyut.Text, checkBox1.Checked, checkBox2.Checked, checkBox3.Checked));
                    }
                    if (CPizzaTuru.Text == "Etli")
                    {
                        MessageBox.Show("Toplam Tutar: " + " " + H.EtliPizzaHesap(CKenarTipi.Text, CBoyut.Text, checkBox1.Checked, checkBox2.Checked, checkBox3.Checked));
                    }
                   

                }
                
                
               

                
            }
            catch (Exception)
            {

                MessageBox.Show("Lütfen doğru seçim yappınız");
            }
                
            
           
            
            

        }
    }
}
